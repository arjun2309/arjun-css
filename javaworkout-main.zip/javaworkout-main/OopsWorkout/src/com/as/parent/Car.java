package com.as.parent;

import com.as.abstra.ChangesHistory;

public class Car extends ChangesHistory {

	private String modelName;
	private double price;
	private String color;
	private int seats;
	private String sound;

	public Car() {
		super();
	}

	public Car(String changesBy, String changesDate, String modelName, double price, String color, int seats,String sound) {
		super(changesBy, changesDate);
		this.modelName = modelName;
		this.price = price;
		this.color = color;
		this.seats = seats;
		this.sound=sound;
	}


	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

	@Override
	public String sound() {
		return sound;
	}

}
