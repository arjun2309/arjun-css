package com.as.abstra;

public abstract class ChangesHistory {
	
	private String changesBy;
	private String changesDate;
	
	public abstract String sound();
	
	
	protected ChangesHistory() {
		super();
	}
	
	protected ChangesHistory(String changesBy,String changesDate){
		this.setChangesBy(changesBy);
		this.setChangesDate(changesDate);
	}

	public String getChangesBy() {
		return changesBy;
	}

	public void setChangesBy(String changesBy) {
		this.changesBy = changesBy;
	}

	public String getChangesDate() {
		return changesDate;
	}

	public void setChangesDate(String changesDate) {
		this.changesDate = changesDate;
	}


	

}
