package com.as.sub;

import com.as.inter.Actions;
import com.as.parent.Car;

public class BMW extends Car implements Actions {
	
	public BMW() {
		super();
	}

	public BMW(String changesBy, String changesDate, String modelName, double price, String color, int seats,String sound) {
		super(changesBy, changesDate, modelName, price, color, seats,sound);
	}

	@Override
	public String movingFront() {
		return "BMW moving front......";
	}

	@Override
	public String movingBack() {
		return "BMW moving back.....";
	}

	@Override
	public String turnRight() {
		return "BMW turning right.....";
	}

	@Override
	public String turnLeft() {
		return "BMW trunning left.....";
	}
	

}
