package com.as.sub;

import com.as.inter.Actions;
import com.as.parent.Car;

public class Honda extends Car implements Actions{
	
	private String specialFeatures;
	
	public Honda() {
		super();
	}
	
	public Honda(String changesBy, String changesDate, String modelName, double price, String color, int seats,String specialFeatures,String sound) {
		super(changesBy, changesDate, modelName, price, color, seats,sound);
		this.specialFeatures=specialFeatures;
	}
	
	public void setSpecialFeatures(String specialFeatures) {
		this.specialFeatures = specialFeatures;
	}

	public String getSpecialFeatures() {
		return specialFeatures;
	}


	@Override
	public String movingFront() {
		return "Honda moving front......";
	}

	@Override
	public String movingBack() {
		return "Honda moving back......";
	}

	@Override
	public String turnRight() {
		return "Honda turn right......";
	}

	@Override
	public String turnLeft() {
		return "Honda turn left.......";
	}
	
	
	public double getPrice(double price,double gstPrice) {
		return price+gstPrice;
	}
	
	

}
