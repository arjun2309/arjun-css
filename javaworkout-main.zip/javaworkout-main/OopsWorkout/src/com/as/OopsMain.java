package com.as;

import java.util.Scanner;

import com.as.inter.Actions;
import com.as.parent.Car;
import com.as.sub.BMW;
import com.as.sub.Honda;

public class OopsMain {

	public static void main(String[] args) {

		Honda honda = new Honda("user", "2023/11/28", "Honda v1", 100000.00, "Blue", 4,"Honda having many features","Rough");
		Car bmw = new BMW("user1", "2023/11/27", "BMW v1", 150000.00, "Red", 6,"Smooth");
		Actions hondaAction = new Honda();
		Actions bmwAction = new BMW();
		Scanner sc = new Scanner(System.in);
		int i=0;
		while (i<=10) {
			System.out.println("Available cars:\n1.Honda \n2.BMW \n3.Exit");
			System.out.println("Enter car name:");
			String selectedCarName = sc.nextLine();
			if (selectedCarName.equalsIgnoreCase("Honda")||selectedCarName.equalsIgnoreCase("1")) {
				System.out.println("Honda Information" + "\n Honda ModelName:" + honda.getModelName()
						+ "\n Honda Color:" + honda.getColor() 
						+ "\n Honda Price:" + honda.getPrice()
						+ "\n Honda With GST:" + honda.getPrice(honda.getPrice(), 1025)
						+ "\n Honda seats:" + honda.getSeats() 
						+ "\n Honda sound:" + honda.sound() 
						+ "\n Honda Features:" + honda.getSpecialFeatures()
						+ "\n Honda changesBy:" + honda.getChangesBy()
						+ "\n Honda changesDate:" + honda.getChangesDate() + "\n === Actions ===" + "\n Front:"
						+ hondaAction.movingFront() + "\n Back: " + hondaAction.movingBack() + "\n Right: "
						+ hondaAction.turnRight() + "\n Left: " + hondaAction.turnLeft()
						+ "\n=========================================");
			} else if (selectedCarName.equalsIgnoreCase("BMW")||selectedCarName.equalsIgnoreCase("2")) {
				System.out.println("BMW Information" + "\n BMW ModelName:" + bmw.getModelName() + "\n BMW Color:"
						+ bmw.getColor() + "\n BMW Price:" + bmw.getPrice() 
						+ "\n BMW Seats:" + bmw.getSeats()
						+ "\n BMW sound:" + bmw.sound()
						+ "\n BMW Changes By:" + bmw.getChangesBy() 
						+ "\n BMW Changes Date:" + bmw.getChangesDate()
						+ "\n === Actions ===" + "\n Front:" + bmwAction.movingFront() + "\n Back: "
						+ bmwAction.movingBack() + "\n Right: " + bmwAction.turnRight() + "\n Left: "
						+ bmwAction.turnLeft() + "\n ========================================");
			} else if(selectedCarName.equalsIgnoreCase("Exit")|| selectedCarName.equalsIgnoreCase("3")) {
				System.out.println("Exited");
				System.exit(0);
			}
			else {
				System.out.println("Car not available");
			}
			i++;
		}
		sc.close();
	}

}
