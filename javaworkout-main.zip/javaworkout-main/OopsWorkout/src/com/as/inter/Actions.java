package com.as.inter;

public interface Actions {
	public String movingFront();
	public String movingBack();
	public String turnRight();
	public String turnLeft();
}
